package com.nova.ai.agent

/** Matches a spoken/typed app name (Arabic or Latin) to an installed launcher app. */
object AppMatcher {
    private val aliases = mapOf(
        "واتساب" to "whatsapp", "وتساب" to "whatsapp", "يوتيوب" to "youtube", "فيسبوك" to "facebook",
        "فيس بوك" to "facebook", "انستغرام" to "instagram", "انستقرام" to "instagram",
        "تيليغرام" to "telegram", "تلغرام" to "telegram", "كروم" to "chrome", "الكاميرا" to "camera",
        "كاميرا" to "camera", "الاعدادات" to "settings", "اعدادات" to "settings", "الهاتف" to "dialer",
        "الرسائل" to "messages", "خرائط" to "maps", "جيميل" to "gmail", "تيك توك" to "tiktok",
        "سناب" to "snapchat", "ماسنجر" to "messenger", "الساعه" to "clock", "الحاسبه" to "calculator",
        "المعرض" to "gallery", "الصور" to "photos", "بلاي ستور" to "play store", "متجر" to "play store"
    )

    fun normalize(s: String): String {
        var t = s.lowercase().trim()
        t = t.replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
        t = t.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
        if (t.startsWith("ال") && t.length > 4) t = t.substring(2)
        return t
    }

    /** [candidates] = (label, packageName). Returns the best package or null. */
    fun best(candidates: List<Pair<String, String>>, query: String): String? {
        val q = normalize(query)
        if (q.isEmpty()) return null
        val variants = listOf(q) +
            aliases.filter { (k, _) -> q.contains(normalize(k)) }.map { it.value }
        var bestPkg: String? = null
        var bestScore = 0
        for ((label, pkg) in candidates) {
            val l = normalize(label)
            val p = pkg.lowercase()
            for (v in variants) {
                val s = when {
                    l == v -> 4
                    l.contains(v) -> 3
                    l.length >= 3 && v.contains(l) -> 2
                    p.contains(v.replace(" ", "")) -> 1
                    else -> 0
                }
                if (s > bestScore) { bestScore = s; bestPkg = pkg }
            }
        }
        return bestPkg
    }
}
