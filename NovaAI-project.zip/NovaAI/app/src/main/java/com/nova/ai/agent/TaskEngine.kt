package com.nova.ai.agent

import com.nova.ai.ai.AiClient
import com.nova.ai.data.MemoryRepository
import com.nova.ai.voice.SpeechOutput
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Turns a user command into a Plan (via the AI), asks for confirmation when needed,
 * executes allowed steps one by one, and verifies each result.
 */
class TaskEngine(
    private val ai: AiClient,
    private val memory: MemoryRepository,
    private val runner: ActionRunner,
    private val speaker: SpeechOutput,
    private val speakEnabled: () -> Boolean
) {
    data class Pending(val plan: Plan, val reasons: List<String>)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()
    private val history = ArrayDeque<Pair<String, String>>()

    private val _status = MutableStateFlow(READY)
    val status: StateFlow<String> = _status.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _log = MutableStateFlow<List<String>>(emptyList())
    val log: StateFlow<List<String>> = _log.asStateFlow()
    private val _pending = MutableStateFlow<Pending?>(null)
    val pending: StateFlow<Pending?> = _pending.asStateFlow()

    fun log(line: String) = _log.update { (it + line).takeLast(60) }
    fun submitAsync(text: String) { scope.launch { submit(text) } }
    fun resolveAsync(ok: Boolean) { scope.launch { resolve(ok) } }

    suspend fun submit(text: String) {
        val cmd = text.trim()
        if (cmd.isEmpty()) return
        mutex.withLock {
            if (_pending.value != null) { _pending.value = null; log("أُلغيت الخطوة المعلّقة بسبب أمر جديد.") }
            log("أنت: $cmd")
            _busy.value = true
            _status.value = "أفكر…"
            try {
                val system = Prompts.system(memory.latest(30).map { it.text })
                val raw = ai.chat(system, history.toList() + ("user" to cmd))
                val plan = PlanParser.parse(raw)
                history.addLast("user" to cmd)
                history.addLast("assistant" to plan.reply.ifBlank { "تم" })
                while (history.size > 8) history.removeFirst()

                plan.remember.forEach { memory.add(it) }
                if (plan.reply.isNotBlank()) {
                    log("Nova: ${plan.reply}")
                    if (speakEnabled()) speaker.speak(plan.reply)
                }
                if (plan.ignored > 0) log("تجاهلت ${plan.ignored} خطوة غير مسموحة.")

                val reasons = plan.actions.mapNotNull { RiskPolicy.reason(it) }
                if (reasons.isNotEmpty()) {
                    _pending.value = Pending(plan, reasons)
                    _status.value = "بانتظار تأكيدك"
                    log("⚠ يلزم تأكيدك: " + reasons.joinToString("، "))
                } else {
                    execute(plan)
                }
            } catch (e: AiClient.AiException) {
                log("⚠ ${e.message}")
                _status.value = "خطأ: ${e.message}"
            } catch (e: Exception) {
                log("⚠ حدث خطأ غير متوقع: ${e.message}")
                _status.value = "خطأ غير متوقع"
            } finally {
                _busy.value = false
                if (_pending.value == null) settleToReady()
            }
        }
    }

    suspend fun resolve(ok: Boolean) {
        mutex.withLock {
            val p = _pending.value ?: return@withLock
            _pending.value = null
            if (!ok) {
                log("أُلغي التنفيذ.")
                _status.value = READY
                return@withLock
            }
            _busy.value = true
            try {
                execute(p.plan)
            } finally {
                _busy.value = false
                settleToReady()
            }
        }
    }

    private suspend fun execute(plan: Plan) {
        if (plan.actions.isEmpty()) { _status.value = READY; return }
        for ((i, a) in plan.actions.withIndex()) {
            _status.value = "خطوة ${i + 1}/${plan.actions.size}: ${describe(a)}"
            val r = runner.run(a)
            log((if (r.ok) "✓ " else "✗ ") + r.message)
            if (!r.ok) {
                _status.value = "توقفت: ${r.message}"
                if (speakEnabled()) speaker.speak("توقفت. ${r.message}")
                return
            }
            delay(700)
        }
        _status.value = "اكتمل ✓"
    }

    private fun settleToReady() {
        scope.launch {
            delay(3000)
            if (!_busy.value && _pending.value == null) _status.value = READY
        }
    }

    private fun describe(a: Action) = when (a) {
        is Action.OpenApp -> "فتح ${a.app}"
        is Action.ClickText -> "ضغط ${a.text}"
        is Action.TypeText -> "كتابة نص"
        is Action.Scroll -> if (a.down) "تمرير لأسفل" else "تمرير لأعلى"
        Action.Back -> "رجوع"
        Action.Home -> "الرئيسية"
        is Action.OpenUrl -> "فتح رابط"
        is Action.SearchWeb -> "بحث"
        is Action.ComposeSms -> "تجهيز رسالة"
        is Action.Call -> "اتصال"
        is Action.Wait -> "انتظار"
    }

    companion object { const val READY = "جاهز" }
}
