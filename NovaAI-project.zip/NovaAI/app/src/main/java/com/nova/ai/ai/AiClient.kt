package com.nova.ai.ai

import com.nova.ai.data.SecureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/** Client for any OpenAI-compatible chat-completions API (Gemini, Groq, OpenRouter, ...). */
class AiClient(
    private val store: SecureStore,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()
) {
    class AiException(message: String) : Exception(message)

    /** [history] is a list of (role, content) pairs; role is "user" or "assistant". */
    suspend fun chat(system: String, history: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            if (store.apiKey.isBlank()) {
                throw AiException("لم تُدخل مفتاح API بعد. افتح الإعدادات وأضفه (مجاني من Google AI Studio أو Groq).")
            }
            val messages = JSONArray().put(JSONObject().put("role", "system").put("content", system))
            history.forEach { (role, content) ->
                messages.put(JSONObject().put("role", role).put("content", content))
            }
            val body = JSONObject()
                .put("model", store.model)
                .put("temperature", 0.2)
                .put("messages", messages)

            val request = Request.Builder()
                .url(store.baseUrl.trimEnd('/') + "/chat/completions")
                .header("Authorization", "Bearer ${store.apiKey}")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            try {
                http.newCall(request).execute().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    when {
                        resp.isSuccessful -> extract(text)
                        resp.code == 401 || resp.code == 403 ->
                            throw AiException("مفتاح API مرفوض. تحقق منه في الإعدادات.")
                        resp.code == 429 ->
                            throw AiException("تجاوزت الحد المجاني المؤقت. انتظر قليلاً ثم أعد المحاولة.")
                        resp.code == 404 ->
                            throw AiException("اسم النموذج أو عنوان API غير صحيح. راجع الإعدادات.")
                        else -> throw AiException("خطأ من المزود (${resp.code}).")
                    }
                }
            } catch (e: UnknownHostException) {
                throw AiException("لا يوجد اتصال بالإنترنت.")
            } catch (e: SocketTimeoutException) {
                throw AiException("انتهت مهلة الاتصال. حاول مجدداً.")
            } catch (e: IOException) {
                throw AiException("تعذر الاتصال بالمزود: ${e.message ?: "خطأ شبكة"}")
            }
        }

    private fun extract(json: String): String = try {
        JSONObject(json).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    } catch (e: Exception) {
        throw AiException("رد غير مفهوم من المزود.")
    }
}
