package com.nova.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.nova.ai.databinding.ActivityCalibrationBinding
import com.nova.ai.vision.CameraService
import com.nova.ai.vision.GazeCalibrator
import com.nova.ai.vision.ModelDownloader
import com.nova.ai.vision.VisionHub
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** 5-point gaze calibration. Uses the local camera session; nothing is recorded. */
class CalibrationActivity : AppCompatActivity() {

    private lateinit var b: ActivityCalibrationBinding
    private var startedCameraHere = false

    private val targets = listOf(
        GazeCalibrator.Target.CENTER to (0.5f to 0.5f),
        GazeCalibrator.Target.LEFT to (0.1f to 0.5f),
        GazeCalibrator.Target.RIGHT to (0.9f to 0.5f),
        GazeCalibrator.Target.UP to (0.5f to 0.12f),
        GazeCalibrator.Target.DOWN to (0.5f to 0.88f)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityCalibrationBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnCalStart.setOnClickListener { begin() }
    }

    private fun begin() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            b.tvCalInfo.text = "امنح إذن الكاميرا من الشاشة الرئيسية أولاً."
            return
        }
        if (!ModelDownloader.ready(this)) {
            b.tvCalInfo.text = "نزّل نماذج الرؤية من الشاشة الرئيسية أولاً."
            return
        }
        b.btnCalStart.visibility = View.GONE
        lifecycleScope.launch {
            if (!VisionHub.state.value.running) {
                startedCameraHere = true
                ContextCompat.startForegroundService(this@CalibrationActivity, Intent(this@CalibrationActivity, CameraService::class.java))
                val up = withTimeoutOrNull(8000) { VisionHub.state.first { it.running } }
                if (up == null) { fail("تعذر تشغيل الكاميرا: ${VisionHub.state.value.message}"); return@launch }
            }
            val cal = GazeCalibrator()
            for ((target, pos) in targets) {
                b.tvCalInfo.text = "انظر إلى النقطة…"
                val w = b.calRoot.width.toFloat(); val h = b.calRoot.height.toFloat()
                b.dot.x = pos.first * w - b.dot.width / 2f
                b.dot.y = pos.second * h - b.dot.height / 2f
                b.dot.visibility = View.VISIBLE
                delay(1500)
                withTimeoutOrNull(2000) {
                    VisionHub.gazeFeatures.collect { cal.add(target, it) }
                }
                if (cal.count(target) < GazeCalibrator.MIN_SAMPLES) {
                    fail("لم يُكتشف وجهك بوضوح. تأكد من الإضاءة وأن وجهك أمام الكاميرا الأمامية.")
                    return@launch
                }
            }
            b.dot.visibility = View.INVISIBLE
            val result = cal.build()
            if (result == null) {
                fail("حركة العين كانت صغيرة جداً للمعايرة. قرّب الهاتف وأعد المحاولة.")
            } else {
                nova.store.calibration = result.serialize()
                b.tvCalInfo.text = "تمت المعايرة ✓ (الدقة تقريبية: أعلى/أسفل/يمين/يسار/وسط)."
                finishCamera()
            }
        }
    }

    private fun fail(msg: String) {
        b.dot.visibility = View.INVISIBLE
        b.tvCalInfo.text = msg
        b.btnCalStart.visibility = View.VISIBLE
        finishCamera()
    }

    private fun finishCamera() {
        if (startedCameraHere) {
            startService(Intent(this, CameraService::class.java).setAction(CameraService.ACTION_STOP))
            startedCameraHere = false
        }
    }

    override fun onDestroy() {
        finishCamera()
        super.onDestroy()
    }
}
