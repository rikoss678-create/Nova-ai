package com.nova.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.ai.vision.ModelDownloader
import com.nova.ai.vision.VisionHub
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = getApplication<NovaApp>().engine

    val status = engine.status
    val log = engine.log
    val pending = engine.pending
    val vision = VisionHub.state

    private val _download = MutableStateFlow("")
    val download: StateFlow<String> = _download.asStateFlow()

    fun submit(text: String) = engine.submitAsync(text)
    fun resolve(ok: Boolean) = engine.resolveAsync(ok)
    fun log(line: String) = engine.log(line)

    fun downloadModels() {
        viewModelScope.launch {
            ModelDownloader.download(getApplication()) { _download.value = it }
        }
    }
}
