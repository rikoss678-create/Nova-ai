package com.nova.ai.vision

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.nova.ai.R
import com.nova.ai.access.NovaAccessibilityService
import com.nova.ai.nova
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Explicit, user-started front-camera session with a persistent notification and a Stop action.
 * All frames are processed on-device and never stored or uploaded.
 */
class CameraService : LifecycleService() {

    private var executor: ExecutorService? = null
    private var provider: ProcessCameraProvider? = null
    private var engine: VisionEngine? = null
    private var started = false

    private var lastFrame = 0L
    private var candidate = ""
    private var candidateCount = 0
    private var lastFire = 0L
    private var calibration: Calibration? = null
    private var calLoadedAt = 0L
    private var gazeLabel = ""
    private var gazeSince = 0L
    private var lastGazeAct = 0L

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "جلسة الكاميرا", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        ServiceCompat.startForeground(this, NOTIF_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        if (started) return START_NOT_STICKY

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            VisionHub.setMessage("إذن الكاميرا غير ممنوح.")
            stopSelf(); return START_NOT_STICKY
        }
        if (!ModelDownloader.ready(this)) {
            VisionHub.setMessage("نماذج الرؤية غير منزّلة بعد. نزّلها من الشاشة الرئيسية.")
            stopSelf(); return START_NOT_STICKY
        }
        started = true
        val exec = Executors.newSingleThreadExecutor().also { executor = it }
        exec.execute {
            try {
                engine = VisionEngine(this)
                val future = ProcessCameraProvider.getInstance(this)
                future.addListener({ bind(future.get()) }, ContextCompat.getMainExecutor(this))
            } catch (e: Exception) {
                VisionHub.setMessage("تعذر تشغيل الرؤية: ${e.message}")
                stopSelf()
            }
        }
        lifecycleScope.launch {
            VisionHub.gestureEvents.collect { handleGesture(it) }
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun bind(p: ProcessCameraProvider) {
        try {
            provider = p
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(android.util.Size(480, 640))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(executor!!) { analyze(it) }
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            VisionHub.setRunning(true, "الكاميرا الأمامية تعمل (معالجة محلية)")
        } catch (e: Exception) {
            VisionHub.setMessage("تعذر فتح الكاميرا الأمامية: ${e.message}")
            stopSelf()
        }
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastFrame < 120) return
            lastFrame = now
            val raw = proxy.toBitmap()
            val m = Matrix().apply {
                postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                postScale(-1f, 1f) // mirror the front camera
            }
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            val out = engine?.process(bmp, now) ?: return
            onGesture(out.gesture, now)
            out.gaze?.let { onGaze(it, now) }
        } catch (e: Exception) {
            VisionHub.setMessage("خطأ في المعالجة: ${e.message}")
        } finally {
            proxy.close()
        }
    }

    private fun onGesture(g: String?, now: Long) {
        if (g == null || g == "None") {
            candidate = ""; candidateCount = 0
            VisionHub.setGesture("")
            return
        }
        VisionHub.setGesture(g)
        if (g == candidate) candidateCount++ else { candidate = g; candidateCount = 1 }
        if (candidateCount >= 3 && now - lastFire > 2000) {
            lastFire = now
            candidateCount = 0
            VisionHub.gestureEvents.tryEmit(g)
        }
    }

    private fun onGaze(f: GazeFeature, now: Long) {
        VisionHub.gazeFeatures.tryEmit(f)
        if (now - calLoadedAt > 3000) {
            calibration = Calibration.parse(nova.store.calibration)
            calLoadedAt = now
        }
        val cal = calibration ?: return
        val label = cal.label(f)
        VisionHub.setGaze(label)
        if (!nova.store.gazeActions) return
        if (label != gazeLabel) { gazeLabel = label; gazeSince = now; return }
        if (now - gazeSince > 1500 && now - lastGazeAct > 2500 && (label == "أعلى" || label == "أسفل")) {
            lastGazeAct = now
            val down = label == "أسفل"
            lifecycleScope.launch { NovaAccessibilityService.instance?.scroll(down) }
        }
    }

    /**
     * Gestures: Open palm = listen, Victory = scroll down, Pointing up = scroll up,
     * Closed fist = back, Thumb down = cancel a pending confirmation.
     * A gesture can never CONFIRM a sensitive action (too error-prone); confirm by tapping.
     */
    private fun handleGesture(g: String) {
        val svc = NovaAccessibilityService.instance
        when (g) {
            "Open_Palm" -> VisionHub.uiCommands.tryEmit("LISTEN")
            "Victory" -> svc?.scroll(true)
            "Pointing_Up" -> svc?.scroll(false)
            "Closed_Fist" -> svc?.back()
            "Thumb_Down" -> if (nova.engine.pending.value != null) nova.engine.resolveAsync(false)
        }
    }

    private fun notification(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, CameraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(getString(R.string.notif_camera_title))
            .setContentText(getString(R.string.notif_camera_text))
            .setOngoing(true)
            .addAction(0, getString(R.string.notif_stop), stop)
            .build()
    }

    override fun onDestroy() {
        try { provider?.unbindAll() } catch (_: Exception) {}
        engine?.close()
        executor?.shutdown()
        VisionHub.setRunning(false, VisionHub.state.value.message)
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.nova.ai.STOP_CAMERA"
        private const val CHANNEL = "nova_camera"
        private const val NOTIF_ID = 2002
    }
}
