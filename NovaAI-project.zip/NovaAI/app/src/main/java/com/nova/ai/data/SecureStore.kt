package com.nova.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Encrypted (Android Keystore backed) storage for the API key and settings. */
class SecureStore(context: Context) {

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "nova_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun str(key: String, def: String) = prefs.getString(key, def) ?: def
    private fun putStr(key: String, v: String) = prefs.edit().putString(key, v).apply()

    var apiKey: String
        get() = str("api_key", "")
        set(v) = putStr("api_key", v.trim())

    var baseUrl: String
        get() = str("base_url", DEFAULT_BASE_URL)
        set(v) = putStr("base_url", v.trim())

    var model: String
        get() = str("model", DEFAULT_MODEL)
        set(v) = putStr("model", v.trim())

    var speakReplies: Boolean
        get() = prefs.getBoolean("speak", true)
        set(v) = prefs.edit().putBoolean("speak", v).apply()

    var gazeActions: Boolean
        get() = prefs.getBoolean("gaze_actions", false)
        set(v) = prefs.edit().putBoolean("gaze_actions", v).apply()

    var calibration: String
        get() = str("calibration", "")
        set(v) = putStr("calibration", v)

    var orbX: Int
        get() = prefs.getInt("orb_x", 24)
        set(v) = prefs.edit().putInt("orb_x", v).apply()

    var orbY: Int
        get() = prefs.getInt("orb_y", 300)
        set(v) = prefs.edit().putInt("orb_y", v).apply()

    companion object {
        const val DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
        const val DEFAULT_MODEL = "gemini-flash-latest"
    }
}
