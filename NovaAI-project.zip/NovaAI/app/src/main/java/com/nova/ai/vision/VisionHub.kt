package com.nova.ai.vision

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/** In-process event bus between the camera service and the UI. Nothing here leaves the device. */
object VisionHub {
    data class State(
        val running: Boolean = false,
        val gesture: String = "",
        val gaze: String = "",
        val message: String = ""
    )

    val state = MutableStateFlow(State())
    val gestureEvents = MutableSharedFlow<String>(extraBufferCapacity = 8, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val gazeFeatures = MutableSharedFlow<GazeFeature>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    /** Commands for the overlay UI, e.g. "LISTEN". */
    val uiCommands = MutableSharedFlow<String>(extraBufferCapacity = 4, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    fun setRunning(r: Boolean, message: String = "") = state.update {
        if (r) it.copy(running = true, message = message) else State(message = message)
    }
    fun setGesture(g: String) = state.update { it.copy(gesture = g) }
    fun setGaze(g: String) = state.update { it.copy(gaze = g) }
    fun setMessage(m: String) = state.update { it.copy(message = m) }
}
