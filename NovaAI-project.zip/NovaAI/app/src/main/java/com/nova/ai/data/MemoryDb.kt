package com.nova.ai.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "memory")
data class MemoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<MemoryItem>>

    @Query("SELECT * FROM memory ORDER BY createdAt DESC LIMIT :n")
    suspend fun latest(n: Int): List<MemoryItem>

    @Insert
    suspend fun insert(item: MemoryItem): Long

    @Delete
    suspend fun delete(item: MemoryItem)

    @Query("DELETE FROM memory")
    suspend fun clear()
}

@Database(entities = [MemoryItem::class], version = 1, exportSchema = false)
abstract class NovaDb : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
}

class MemoryRepository(private val dao: MemoryDao) {
    val all: Flow<List<MemoryItem>> = dao.observeAll()

    suspend fun latest(n: Int = 30): List<MemoryItem> = dao.latest(n)

    /** Adds a fact unless an identical one already exists. */
    suspend fun add(text: String) {
        val t = text.trim().take(300)
        if (t.isEmpty()) return
        if (dao.latest(200).any { it.text == t }) return
        dao.insert(MemoryItem(text = t))
    }

    suspend fun delete(item: MemoryItem) = dao.delete(item)
    suspend fun clear() = dao.clear()
}
