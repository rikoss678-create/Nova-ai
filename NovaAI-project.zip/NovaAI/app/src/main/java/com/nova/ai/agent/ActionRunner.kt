package com.nova.ai.agent

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.nova.ai.access.NovaAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.URLEncoder

/** Executes one allowed [Action] and verifies the outcome when the platform allows it. */
class ActionRunner(private val ctx: Context) {

    data class Result(val ok: Boolean, val message: String)

    suspend fun run(a: Action): Result = try {
        dispatch(a)
    } catch (e: ActivityNotFoundException) {
        Result(false, "لا يوجد تطبيق على الهاتف يتعامل مع هذا الأمر.")
    } catch (e: SecurityException) {
        Result(false, "رفض النظام هذا الإجراء.")
    }

    private suspend fun dispatch(a: Action): Result = when (a) {
        is Action.OpenApp -> openApp(a.app)
        is Action.ClickText -> a11y { if (it.clickText(a.text)) Result(true, "ضغطت على «${a.text}»") else Result(false, "لم أجد «${a.text}» قابلاً للضغط على الشاشة") }
        is Action.TypeText -> a11y { if (it.typeText(a.text)) Result(true, "كتبت النص") else Result(false, "لا يوجد حقل نص مناسب (أو أنه حقل كلمة مرور)") }
        is Action.Scroll -> a11y { if (it.scroll(a.down)) Result(true, if (a.down) "مررت للأسفل" else "مررت للأعلى") else Result(false, "تعذر التمرير") }
        Action.Back -> a11y { if (it.back()) Result(true, "رجعت للخلف") else Result(false, "تعذر الرجوع") }
        Action.Home -> a11y { if (it.home()) Result(true, "ذهبت للشاشة الرئيسية") else Result(false, "تعذر الذهاب للرئيسية") }
        is Action.OpenUrl -> {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse(a.url)))
            Result(true, "فتحت الرابط")
        }
        is Action.SearchWeb -> {
            val q = URLEncoder.encode(a.query, "UTF-8")
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q")))
            Result(true, "بحثت عن «${a.query}»")
        }
        is Action.ComposeSms -> {
            launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(a.to)}")).putExtra("sms_body", a.text))
            Result(true, "جهّزت الرسالة؛ اضغط «إرسال» في تطبيق الرسائل لإتمامها")
        }
        is Action.Call -> {
            launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(a.to)}")))
            Result(true, "فتحت لوحة الاتصال؛ اضغط زر الاتصال لإتمامه")
        }
        is Action.Wait -> {
            delay(a.ms)
            Result(true, "انتظرت")
        }
    }

    private fun launch(i: Intent) {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private suspend fun a11y(block: (NovaAccessibilityService) -> Result): Result {
        val s = NovaAccessibilityService.instance
            ?: return Result(false, "خدمة إمكانية الوصول غير مفعّلة. فعّلها من الشاشة الرئيسية.")
        return withContext(Dispatchers.Main) { block(s) }
    }

    @Suppress("DEPRECATION")
    private suspend fun openApp(name: String): Result {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val pkg = AppMatcher.best(apps, name) ?: return Result(false, "لم أجد تطبيقاً باسم «$name»")
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return Result(false, "تعذر فتح «$name»")
        launch(intent)
        delay(1500)
        val svc = NovaAccessibilityService.instance
            ?: return Result(true, "أرسلت أمر فتح «$name» (لا أستطيع التحقق دون خدمة إمكانية الوصول)")
        val current = withContext(Dispatchers.Main) { svc.currentPackage() }
        return if (current == pkg) Result(true, "تم فتح «$name»")
        else Result(false, "حاولت فتح «$name» لكن الشاشة الحالية تابعة لتطبيق آخر")
    }
}
