package com.nova.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.EditorInfo
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.nova.ai.access.NovaAccessibilityService
import com.nova.ai.agent.TaskEngine
import com.nova.ai.databinding.ActivityMainBinding
import com.nova.ai.overlay.OverlayService
import com.nova.ai.vision.CameraService
import com.nova.ai.vision.ModelDownloader
import com.nova.ai.vision.VisionHub
import com.nova.ai.voice.SpeechInput
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()
    private lateinit var speech: SpeechInput

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshChecklist()
    }
    private val audioLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        refreshChecklist()
        if (ok) startVoice()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        speech = SpeechInput(this)

        b.btnPerms.setOnClickListener { requestRuntimePermissions() }
        b.btnOrb.setOnClickListener { toggleOrb() }
        b.btnAccess.setOnClickListener { openAccessibility() }
        b.btnModels.setOnClickListener {
            if (ModelDownloader.ready(this)) vm.log("نماذج الرؤية منزّلة مسبقاً ✓") else vm.downloadModels()
        }
        b.btnCamera.setOnClickListener { toggleCamera() }
        b.btnCalibrate.setOnClickListener { startActivity(Intent(this, CalibrationActivity::class.java)) }
        b.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        b.btnMemory.setOnClickListener { startActivity(Intent(this, MemoryActivity::class.java)) }
        b.btnSend.setOnClickListener { send() }
        b.etCommand.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        b.btnMic.setOnClickListener { startVoice() }
        b.btnConfirm.setOnClickListener { vm.resolve(true) }
        b.btnCancel.setOnClickListener { vm.resolve(false) }

        collect()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_ASK_AUDIO, false) == true) {
            audioLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshChecklist()
    }

    override fun onDestroy() {
        speech.stop()
        super.onDestroy()
    }

    private fun collect() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { vm.status.collect { b.tvStatus.text = "الحالة: $it" } }
                launch { vm.log.collect { b.tvLog.text = it.takeLast(25).joinToString("\n") } }
                launch {
                    vm.pending.collect { p ->
                        if (p == null) b.cardPending.visibility = android.view.View.GONE
                        else {
                            b.tvPending.text = "تأكيد مطلوب قبل التنفيذ:\n" + p.reasons.joinToString("\n") { "• $it" }
                            b.cardPending.visibility = android.view.View.VISIBLE
                        }
                    }
                }
                launch {
                    vm.vision.collect { st ->
                        b.btnCamera.text = getString(if (st.running) R.string.btn_camera_stop else R.string.btn_camera_start)
                        refreshChecklist()
                    }
                }
                launch { vm.download.collect { if (it.isNotEmpty()) { vm.log(it); refreshChecklist() } } }
            }
        }
    }

    private fun mark(ok: Boolean) = if (ok) "✅" else "⬜"

    private fun hasPerm(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun refreshChecklist() {
        val overlay = Settings.canDrawOverlays(this)
        val access = NovaAccessibilityService.instance != null
        val st = VisionHub.state.value
        val lines = buildList {
            add("${mark(overlay)} إذن الظهور فوق التطبيقات")
            add("${mark(hasPerm(Manifest.permission.RECORD_AUDIO))} الميكروفون")
            add("${mark(hasPerm(Manifest.permission.CAMERA))} الكاميرا")
            add("${mark(access)} خدمة إمكانية الوصول (اختيارية — للتحكم بالتطبيقات)")
            add("${mark(ModelDownloader.ready(this@MainActivity))} نماذج الرؤية")
            add("${mark(OverlayService.isRunning)} النواة العائمة")
            add("${mark(st.running)} الكاميرا ${if (st.running) "(تعمل — معالجة محلية)" else ""}")
            if (st.message.isNotBlank()) add("ℹ ${st.message}")
            if (st.running && st.gesture.isNotBlank()) add("✋ إشارة اليد: ${st.gesture}")
            if (st.running && st.gaze.isNotBlank()) add("👁 النظر: ${st.gaze}")
        }
        b.tvChecklist.text = lines.joinToString("\n")
        b.btnOrb.text = getString(if (OverlayService.isRunning) R.string.btn_stop_orb else R.string.btn_start_orb)
    }

    private fun requestRuntimePermissions() {
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        permLauncher.launch(list.toTypedArray())
    }

    private fun toggleOrb() {
        if (OverlayService.isRunning) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            b.root.postDelayed({ refreshChecklist() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setMessage("لإظهار النواة فوق التطبيقات يلزم إذن «الظهور فوق التطبيقات». فعّله لـ Nova ثم ارجع.")
                .setPositiveButton("فتح الإعدادات") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        b.root.postDelayed({ refreshChecklist() }, 500)
    }

    private fun openAccessibility() {
        AlertDialog.Builder(this)
            .setMessage(
                "ستفتح إعدادات إمكانية الوصول؛ اختر «Nova AI» وفعّله يدوياً.\n\n" +
                    "على أندرويد 13، إن ظهر أن الإعداد «مقيّد»: افتح معلومات التطبيق (إعدادات ← التطبيقات ← Nova AI)، " +
                    "اضغط ⋮ ثم «السماح بالإعدادات المقيّدة»، ثم أعد التفعيل."
            )
            .setPositiveButton("متابعة") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNeutralButton("معلومات التطبيق") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun toggleCamera() {
        if (VisionHub.state.value.running) {
            startService(Intent(this, CameraService::class.java).setAction(CameraService.ACTION_STOP))
            return
        }
        if (!hasPerm(Manifest.permission.CAMERA)) { requestRuntimePermissions(); return }
        if (!ModelDownloader.ready(this)) { vm.log("نزّل نماذج الرؤية أولاً (الزر أعلاه)."); return }
        ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
    }

    private fun startVoice() {
        if (!speech.hasPermission()) { audioLauncher.launch(Manifest.permission.RECORD_AUDIO); return }
        speech.start(object : SpeechInput.Callback {
            override fun onListening() { vm.log("🎤 أسمعك…") }
            override fun onPartial(text: String) { b.etCommand.setText(text) }
            override fun onResult(text: String) { b.etCommand.setText(""); vm.submit(text) }
            override fun onError(message: String) { vm.log("⚠ $message") }
        })
    }

    private fun send() {
        val t = b.etCommand.text.toString().trim()
        if (t.isEmpty()) return
        b.etCommand.setText("")
        vm.submit(t)
    }

    companion object {
        const val EXTRA_ASK_AUDIO = "ask_audio"
    }
}
