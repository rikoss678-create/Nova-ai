package com.nova.ai

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.nova.ai.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private data class Preset(val name: String, val url: String, val model: String)

    private val presets = listOf(
        Preset("Google Gemini (مجاني)", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-flash-latest"),
        Preset("Groq (مجاني)", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
        Preset("OpenRouter (نماذج :free)", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free"),
        Preset("مخصص", "", "")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        val store = nova.store

        b.etBaseUrl.setText(store.baseUrl)
        b.etModel.setText(store.model)
        b.etApiKey.setText(store.apiKey)
        b.swSpeak.isChecked = store.speakReplies
        b.swGaze.isChecked = store.gazeActions

        b.spProvider.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presets.map { it.name })
        val initial = presets.indexOfFirst { it.url == store.baseUrl }.let { if (it < 0) presets.lastIndex else it }
        b.spProvider.setSelection(initial, false)
        b.spProvider.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val preset = presets[pos]
                if (preset.url.isNotEmpty()) {
                    b.etBaseUrl.setText(preset.url)
                    b.etModel.setText(preset.model)
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        b.btnSave.setOnClickListener {
            val url = b.etBaseUrl.text.toString().trim()
            if (!url.startsWith("https://")) {
                Toast.makeText(this, "يجب أن يبدأ العنوان بـ https://", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            store.baseUrl = url
            store.model = b.etModel.text.toString()
            store.apiKey = b.etApiKey.text.toString()
            store.speakReplies = b.swSpeak.isChecked
            store.gazeActions = b.swGaze.isChecked
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
