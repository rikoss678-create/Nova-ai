package com.nova.ai.agent

import org.json.JSONException
import org.json.JSONObject

/** The ONLY steps Nova can execute. Anything else returned by the model is discarded. */
sealed class Action {
    data class OpenApp(val app: String) : Action()
    data class ClickText(val text: String) : Action()
    data class TypeText(val text: String) : Action()
    data class Scroll(val down: Boolean) : Action()
    object Back : Action()
    object Home : Action()
    data class OpenUrl(val url: String) : Action()
    data class SearchWeb(val query: String) : Action()
    data class ComposeSms(val to: String, val text: String) : Action()
    data class Call(val to: String) : Action()
    data class Wait(val ms: Long) : Action()
}

data class Plan(
    val reply: String,
    val actions: List<Action>,
    val remember: List<String>,
    val ignored: Int = 0
)

object PlanParser {
    private const val MAX_ACTIONS = 8

    fun parse(raw: String): Plan {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return Plan(raw.trim(), emptyList(), emptyList())
        return try {
            val o = JSONObject(raw.substring(start, end + 1))
            val arr = o.optJSONArray("actions")
            val actions = mutableListOf<Action>()
            var ignored = 0
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val a = arr.optJSONObject(i)?.let { toAction(it) }
                    if (a == null) ignored++ else if (actions.size < MAX_ACTIONS) actions += a else ignored++
                }
            }
            val mem = mutableListOf<String>()
            o.optJSONArray("remember")?.let { m ->
                for (i in 0 until m.length()) m.optString(i).trim().takeIf { it.isNotEmpty() }?.let { mem += it }
            }
            Plan(o.optString("reply").trim(), actions, mem, ignored)
        } catch (e: JSONException) {
            Plan(raw.trim(), emptyList(), emptyList())
        }
    }

    private fun toAction(o: JSONObject): Action? = when (o.optString("type").trim().uppercase()) {
        "OPEN_APP" -> o.optString("app").trim().takeIf { it.isNotEmpty() }?.let { Action.OpenApp(it) }
        "CLICK_TEXT" -> o.optString("text").trim().takeIf { it.isNotEmpty() }?.let { Action.ClickText(it) }
        "TYPE_TEXT" -> o.optString("text").takeIf { it.isNotEmpty() }?.let { Action.TypeText(it) }
        "SCROLL" -> Action.Scroll(o.optString("dir", "down").trim().lowercase() != "up")
        "BACK" -> Action.Back
        "HOME" -> Action.Home
        "OPEN_URL" -> o.optString("url").trim()
            .takeIf { it.startsWith("https://") || it.startsWith("http://") }?.let { Action.OpenUrl(it) }
        "SEARCH_WEB" -> o.optString("query").trim().takeIf { it.isNotEmpty() }?.let { Action.SearchWeb(it) }
        "COMPOSE_SMS" -> {
            val to = o.optString("to").trim()
            if (to.isEmpty()) null else Action.ComposeSms(to, o.optString("text"))
        }
        "CALL" -> o.optString("to").trim().takeIf { it.isNotEmpty() }?.let { Action.Call(it) }
        "WAIT" -> Action.Wait(o.optLong("ms", 1000).coerceIn(0, 5000))
        else -> null
    }
}
