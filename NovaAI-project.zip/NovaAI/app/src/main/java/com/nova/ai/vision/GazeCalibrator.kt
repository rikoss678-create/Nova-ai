package com.nova.ai.vision

import kotlin.math.abs

/** Iris position ratios inside the eye box (0..1 horizontally and vertically). */
data class GazeFeature(val rx: Float, val ry: Float)

/** Pure math on MediaPipe face-mesh landmarks (478 points incl. irises). */
object GazeMath {
    private const val MIN_EYE_OPENING = 0.008f

    fun feature(count: Int, x: (Int) -> Float, y: (Int) -> Float): GazeFeature? {
        if (count < 478) return null
        fun rx(iris: Int, a: Int, b: Int): Float? {
            val d = x(b) - x(a)
            return if (abs(d) < 1e-4f) null else (x(iris) - x(a)) / d
        }
        fun ry(iris: Int, up: Int, low: Int): Float? {
            val d = y(low) - y(up)
            return if (d < MIN_EYE_OPENING) null else (y(iris) - y(up)) / d // null on blink
        }
        val xs = listOfNotNull(rx(468, 33, 133), rx(473, 362, 263))
        val ys = listOfNotNull(ry(468, 159, 145), ry(473, 386, 374))
        if (xs.isEmpty() || ys.isEmpty()) return null
        return GazeFeature(xs.average().toFloat(), ys.average().toFloat())
    }
}

data class Calibration(
    val cx: Float, val cy: Float,
    val leftX: Float, val rightX: Float,
    val upY: Float, val downY: Float
) {
    /** Maps a feature to screen-normalized gaze (0..1, 0,0 = top-left). */
    fun normalize(f: GazeFeature): Pair<Float, Float> = Pair(
        ((f.rx - leftX) / (rightX - leftX)).coerceIn(0f, 1f),
        ((f.ry - upY) / (downY - upY)).coerceIn(0f, 1f)
    )

    fun label(f: GazeFeature): String {
        val (gx, gy) = normalize(f)
        return when {
            gy < 0.3f -> "أعلى"
            gy > 0.7f -> "أسفل"
            gx < 0.3f -> "يسار"
            gx > 0.7f -> "يمين"
            else -> "وسط"
        }
    }

    fun serialize() = listOf(cx, cy, leftX, rightX, upY, downY).joinToString(",")

    companion object {
        fun parse(s: String): Calibration? {
            val p = s.split(",").mapNotNull { it.trim().toFloatOrNull() }
            return if (p.size == 6) Calibration(p[0], p[1], p[2], p[3], p[4], p[5]) else null
        }
    }
}

class GazeCalibrator {
    enum class Target { CENTER, LEFT, RIGHT, UP, DOWN }

    private val samples = mutableMapOf<Target, MutableList<GazeFeature>>()

    fun add(t: Target, f: GazeFeature) {
        samples.getOrPut(t) { mutableListOf() }.add(f)
    }

    fun count(t: Target) = samples[t]?.size ?: 0

    private fun mean(t: Target): GazeFeature? {
        val l = samples[t] ?: return null
        if (l.size < MIN_SAMPLES) return null
        return GazeFeature(l.map { it.rx }.average().toFloat(), l.map { it.ry }.average().toFloat())
    }

    /** Returns null when data is insufficient or the eye movement range is too small to be reliable. */
    fun build(): Calibration? {
        val c = mean(Target.CENTER) ?: return null
        val l = mean(Target.LEFT) ?: return null
        val r = mean(Target.RIGHT) ?: return null
        val u = mean(Target.UP) ?: return null
        val d = mean(Target.DOWN) ?: return null
        if (abs(r.rx - l.rx) < 0.03f || abs(d.ry - u.ry) < 0.02f) return null
        return Calibration(c.rx, c.ry, l.rx, r.rx, u.ry, d.ry)
    }

    companion object { const val MIN_SAMPLES = 5 }
}
