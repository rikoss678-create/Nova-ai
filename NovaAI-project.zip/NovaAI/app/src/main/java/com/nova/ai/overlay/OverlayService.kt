package com.nova.ai.overlay

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.nova.ai.MainActivity
import com.nova.ai.R
import com.nova.ai.agent.TaskEngine
import com.nova.ai.databinding.OverlayOrbBinding
import com.nova.ai.databinding.OverlayPanelBinding
import com.nova.ai.nova
import com.nova.ai.vision.CameraService
import com.nova.ai.vision.ModelDownloader
import com.nova.ai.vision.VisionHub
import com.nova.ai.voice.SpeechInput
import kotlinx.coroutines.launch
import kotlin.math.abs

/** The floating "core": a draggable orb over other apps with a small command panel. */
class OverlayService : LifecycleService() {

    private lateinit var wm: WindowManager
    private var orb: OverlayOrbBinding? = null
    private var panel: OverlayPanelBinding? = null
    private lateinit var orbParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private var panelShown = false
    private var listening = false
    private lateinit var speech: SpeechInput

    private val engine get() = nova.engine

    override fun onCreate() {
        super.onCreate()
        // Must call startForeground promptly after startForegroundService().
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
        isRunning = true

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        speech = SpeechInput(this)
        val themed = ContextThemeWrapper(this, R.style.Theme_Nova)
        val inflater = LayoutInflater.from(themed)
        orb = OverlayOrbBinding.inflate(inflater)
        panel = OverlayPanelBinding.inflate(inflater)
        setupOrb()
        setupPanel()
        observe()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupOrb() {
        val b = orb ?: return
        orbParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = nova.store.orbX
            y = nova.store.orbY
        }
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        b.root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = orbParams.x; startY = orbParams.y
                    touchX = e.rawX; touchY = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        orbParams.x = startX + dx
                        orbParams.y = startY + dy
                        wm.updateViewLayout(b.root, orbParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { nova.store.orbX = orbParams.x; nova.store.orbY = orbParams.y } else togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(b.root, orbParams)
        refreshOrb()
    }

    private fun setupPanel() {
        val p = panel ?: return
        panelParams = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.94f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = (24 * resources.displayMetrics.density).toInt()
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        p.btnSend.setOnClickListener { submitFromPanel() }
        p.etInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { submitFromPanel(); true } else false
        }
        p.btnMic.setOnClickListener { startListening() }
        p.btnClose.setOnClickListener { hidePanel() }
        p.btnConfirm.setOnClickListener { engine.resolveAsync(true); hidePanel() }
        p.btnCancel.setOnClickListener { engine.resolveAsync(false); hidePanel() }
        p.btnCam.setOnClickListener { toggleCamera() }
    }

    private fun observe() {
        lifecycleScope.launch {
            engine.status.collect { s ->
                val chip = orb?.orbStatus ?: return@collect
                if (s == TaskEngine.READY) chip.visibility = View.GONE
                else { chip.text = s; chip.visibility = View.VISIBLE }
            }
        }
        lifecycleScope.launch { engine.busy.collect { refreshOrb() } }
        lifecycleScope.launch {
            VisionHub.state.collect { st ->
                refreshOrb()
                panel?.btnCam?.text = if (st.running) "إيقاف الكاميرا" else getString(R.string.overlay_camera)
            }
        }
        lifecycleScope.launch {
            engine.log.collect { lines ->
                val p = panel ?: return@collect
                p.tvLog.text = lines.takeLast(12).joinToString("\n")
                p.logScroll.post { p.logScroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
        lifecycleScope.launch {
            engine.pending.collect { pend ->
                val p = panel ?: return@collect
                if (pend == null) {
                    p.confirmRow.visibility = View.GONE
                } else {
                    p.tvConfirm.text = "تأكيد مطلوب:\n" + pend.reasons.joinToString("\n") { "• $it" }
                    p.confirmRow.visibility = View.VISIBLE
                    showPanel()
                }
            }
        }
        lifecycleScope.launch {
            VisionHub.uiCommands.collect { if (it == "LISTEN") startListening() }
        }
    }

    private fun refreshOrb() {
        val b = orb ?: return
        val fill = when {
            listening -> R.color.nova_green
            engine.busy.value -> R.color.nova_amber
            else -> R.color.nova_blue
        }
        val d = b.orb.background.mutate() as GradientDrawable
        d.setColor(ContextCompat.getColor(this, fill))
        // Red ring = camera session active.
        if (VisionHub.state.value.running) d.setStroke((4 * resources.displayMetrics.density).toInt(), ContextCompat.getColor(this, R.color.nova_red))
        else d.setStroke((3 * resources.displayMetrics.density).toInt(), 0x66FFFFFF)
    }

    private fun togglePanel() = if (panelShown) hidePanel() else showPanel()

    private fun showPanel() {
        val p = panel ?: return
        if (panelShown) return
        try {
            wm.addView(p.root, panelParams)
            panelShown = true
        } catch (_: Exception) {}
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (!panelShown) return
        try {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(p.root.windowToken, 0)
            wm.removeView(p.root)
        } catch (_: Exception) {}
        panelShown = false
    }

    private fun submitFromPanel() {
        val p = panel ?: return
        val t = p.etInput.text.toString().trim()
        if (t.isEmpty()) return
        p.etInput.setText("")
        hidePanel() // so the target app, not our panel, is the active window
        engine.submitAsync(t)
    }

    private fun startListening() {
        if (!speech.hasPermission()) {
            engine.log("⚠ امنح إذن الميكروفون من التطبيق.")
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_ASK_AUDIO, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        listening = true
        refreshOrb()
        speech.start(object : SpeechInput.Callback {
            override fun onListening() { engine.log("🎤 أسمعك…") }
            override fun onPartial(text: String) {}
            override fun onResult(text: String) {
                listening = false; refreshOrb()
                hidePanel()
                engine.submitAsync(text)
            }
            override fun onError(message: String) {
                listening = false; refreshOrb()
                engine.log("⚠ $message")
            }
        })
    }

    private fun toggleCamera() {
        if (VisionHub.state.value.running) {
            startService(Intent(this, CameraService::class.java).setAction(CameraService.ACTION_STOP))
            return
        }
        val hasCam = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (!hasCam || !ModelDownloader.ready(this)) {
            engine.log("⚠ امنح إذن الكاميرا ونزّل نماذج الرؤية من التطبيق أولاً.")
            return
        }
        try {
            ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
        } catch (e: Exception) {
            engine.log("⚠ لا يسمح النظام بتشغيل الكاميرا من الخلفية. ابدأها من تطبيق Nova.")
        }
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "النواة العائمة", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(R.drawable.ic_notif)
        .setContentTitle(getString(R.string.notif_overlay_title))
        .setContentText(getString(R.string.notif_overlay_text))
        .setOngoing(true)
        .addAction(
            0, getString(R.string.notif_stop),
            PendingIntent.getService(
                this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .build()

    override fun onDestroy() {
        isRunning = false
        hidePanel()
        try { orb?.root?.let { wm.removeView(it) } } catch (_: Exception) {}
        if (::speech.isInitialized) speech.stop()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.nova.ai.STOP_OVERLAY"
        private const val CHANNEL = "nova_overlay"
        private const val NOTIF_ID = 1001
        @Volatile var isRunning = false
    }
}
