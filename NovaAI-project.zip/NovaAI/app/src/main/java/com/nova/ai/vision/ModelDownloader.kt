package com.nova.ai.vision

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Downloads the free MediaPipe model files once (about 12 MB) into app-private storage. */
object ModelDownloader {
    const val GESTURE = "gesture_recognizer.task"
    const val FACE = "face_landmarker.task"

    private val urls = mapOf(
        GESTURE to "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task",
        FACE to "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
    )

    fun dir(ctx: Context): File = File(ctx.filesDir, "models").apply { mkdirs() }
    fun file(ctx: Context, name: String) = File(dir(ctx), name)
    fun ready(ctx: Context) = urls.keys.all { file(ctx, it).let { f -> f.exists() && f.length() > 1_000_000 } }

    suspend fun download(ctx: Context, onProgress: (String) -> Unit): Result<Unit> = withContext(Dispatchers.IO) {
        val client = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
        try {
            for ((name, url) in urls) {
                val target = file(ctx, name)
                if (target.exists() && target.length() > 1_000_000) continue
                onProgress("جارٍ تنزيل $name …")
                val tmp = File(target.path + ".part")
                client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                    val body = resp.body ?: throw IOException("رد فارغ")
                    body.byteStream().use { input -> tmp.outputStream().use { input.copyTo(it) } }
                }
                if (!tmp.renameTo(target)) throw IOException("تعذر حفظ الملف")
            }
            onProgress("اكتمل تنزيل النماذج ✓")
            Result.success(Unit)
        } catch (e: Exception) {
            onProgress("فشل التنزيل: ${e.message ?: "تحقق من الإنترنت"}")
            Result.failure(e)
        }
    }
}
