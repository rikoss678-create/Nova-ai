package com.nova.ai

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nova.ai.data.MemoryItem
import com.nova.ai.databinding.ActivityMemoryBinding
import com.nova.ai.databinding.ItemMemoryBinding
import kotlinx.coroutines.launch

class MemoryActivity : AppCompatActivity() {

    private class Adapter(val onDelete: (MemoryItem) -> Unit) :
        ListAdapter<MemoryItem, Adapter.VH>(object : DiffUtil.ItemCallback<MemoryItem>() {
            override fun areItemsTheSame(a: MemoryItem, b: MemoryItem) = a.id == b.id
            override fun areContentsTheSame(a: MemoryItem, b: MemoryItem) = a == b
        }) {
        class VH(val b: ItemMemoryBinding) : RecyclerView.ViewHolder(b.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemMemoryBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = getItem(position)
            holder.b.tvText.text = item.text
            holder.b.btnDelete.setOnClickListener { onDelete(item) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityMemoryBinding.inflate(layoutInflater)
        setContentView(b.root)
        val repo = nova.memory
        val adapter = Adapter { item -> lifecycleScope.launch { repo.delete(item) } }
        b.rvMemory.layoutManager = LinearLayoutManager(this)
        b.rvMemory.adapter = adapter

        lifecycleScope.launch { repo.all.collect { adapter.submitList(it) } }

        b.btnAdd.setOnClickListener {
            val t = b.etMemory.text.toString()
            if (t.isNotBlank()) {
                lifecycleScope.launch { repo.add(t) }
                b.etMemory.setText("")
            }
        }
        b.btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("حذف كل ما تتذكره Nova عنك؟ لا يمكن التراجع.")
                .setPositiveButton(R.string.btn_delete) { _, _ -> lifecycleScope.launch { repo.clear() } }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
        }
    }
}
