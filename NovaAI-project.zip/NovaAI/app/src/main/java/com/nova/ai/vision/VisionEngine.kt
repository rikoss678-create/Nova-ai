package com.nova.ai.vision

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import java.io.Closeable
import java.nio.ByteBuffer

/** Local (on-device) hand-gesture recognition and face/iris landmarks via MediaPipe. */
class VisionEngine(ctx: Context) : Closeable {

    data class Output(val gesture: String?, val gaze: GazeFeature?)

    private val gesture: GestureRecognizer
    private val face: FaceLandmarker

    init {
        gesture = GestureRecognizer.createFromOptions(
            ctx,
            GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(load(ctx, ModelDownloader.GESTURE)).build())
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(1)
                .build()
        )
        face = FaceLandmarker.createFromOptions(
            ctx,
            FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(load(ctx, ModelDownloader.FACE)).build())
                .setRunningMode(RunningMode.VIDEO)
                .setNumFaces(1)
                .build()
        )
    }

    private fun load(ctx: Context, name: String): ByteBuffer {
        val bytes = ModelDownloader.file(ctx, name).readBytes()
        return ByteBuffer.allocateDirect(bytes.size).put(bytes).also { it.rewind() }
    }

    /** [bitmap] must already be upright (and mirrored for the front camera). [tsMs] must increase. */
    fun process(bitmap: Bitmap, tsMs: Long): Output {
        val image = BitmapImageBuilder(bitmap).build()
        val g = gesture.recognizeForVideo(image, tsMs)
        val top = g.gestures().firstOrNull()?.firstOrNull()
        val name = if (top != null && top.score() >= 0.7f) top.categoryName() else null

        val f = face.detectForVideo(image, tsMs)
        val lm = f.faceLandmarks().firstOrNull()
        val feature = lm?.let { l -> GazeMath.feature(l.size, { l[it].x() }, { l[it].y() }) }
        return Output(name, feature)
    }

    override fun close() {
        gesture.close()
        face.close()
    }
}
