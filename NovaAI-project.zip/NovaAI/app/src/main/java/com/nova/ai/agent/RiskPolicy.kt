package com.nova.ai.agent

/** Decides which steps need an explicit tap-to-confirm from the user (messages, deletion, payments). */
object RiskPolicy {
    private val sensitiveWords = listOf(
        "send", "pay", "buy", "purchase", "delete", "remove", "transfer", "checkout", "place order",
        "إرسال", "ارسال", "أرسل", "ارسل", "دفع", "ادفع", "شراء", "اشتر", "حذف", "احذف", "مسح",
        "إزالة", "ازالة", "تحويل", "حوّل", "تأكيد الطلب", "اتمام الشراء", "إتمام الشراء"
    )

    /** Returns an Arabic reason if confirmation is required, otherwise null. */
    fun reason(a: Action): String? = when (a) {
        is Action.ComposeSms -> "تجهيز رسالة إلى ${a.to}"
        is Action.Call -> "الاتصال بالرقم ${a.to}"
        is Action.ClickText ->
            if (isSensitive(a.text)) "الضغط على «${a.text}» (إرسال/حذف/دفع)" else null
        else -> null
    }

    fun isSensitive(text: String): Boolean {
        val t = text.lowercase()
        return sensitiveWords.any { t.contains(it) }
    }
}
