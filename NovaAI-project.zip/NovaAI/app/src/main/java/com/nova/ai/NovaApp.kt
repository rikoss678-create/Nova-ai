package com.nova.ai

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.nova.ai.agent.ActionRunner
import com.nova.ai.agent.TaskEngine
import com.nova.ai.ai.AiClient
import com.nova.ai.data.MemoryRepository
import com.nova.ai.data.NovaDb
import com.nova.ai.data.SecureStore
import com.nova.ai.voice.SpeechOutput

class NovaApp : Application() {
    val store by lazy { SecureStore(this) }
    private val db by lazy { Room.databaseBuilder(this, NovaDb::class.java, "nova.db").build() }
    val memory by lazy { MemoryRepository(db.memoryDao()) }
    val speaker by lazy { SpeechOutput(this) }
    val engine by lazy {
        TaskEngine(AiClient(store), memory, ActionRunner(this), speaker) { store.speakReplies }
    }
}

val Context.nova: NovaApp get() = applicationContext as NovaApp
