package com.nova.ai

import com.nova.ai.vision.Calibration
import com.nova.ai.vision.GazeCalibrator
import com.nova.ai.vision.GazeFeature
import com.nova.ai.vision.GazeMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class GazeCalibratorTest {
    private fun fill(c: GazeCalibrator, t: GazeCalibrator.Target, x: Float, y: Float) =
        repeat(6) { c.add(t, GazeFeature(x, y)) }

    private fun good(): GazeCalibrator = GazeCalibrator().also {
        fill(it, GazeCalibrator.Target.CENTER, 0.50f, 0.50f)
        fill(it, GazeCalibrator.Target.LEFT, 0.35f, 0.50f)
        fill(it, GazeCalibrator.Target.RIGHT, 0.65f, 0.50f)
        fill(it, GazeCalibrator.Target.UP, 0.50f, 0.40f)
        fill(it, GazeCalibrator.Target.DOWN, 0.50f, 0.60f)
    }

    @Test fun buildsAndLabels() {
        val cal = good().build()
        assertNotNull(cal)
        assertEquals("وسط", cal!!.label(GazeFeature(0.50f, 0.50f)))
        assertEquals("يسار", cal.label(GazeFeature(0.36f, 0.50f)))
        assertEquals("يمين", cal.label(GazeFeature(0.64f, 0.50f)))
        assertEquals("أعلى", cal.label(GazeFeature(0.50f, 0.40f)))
        assertEquals("أسفل", cal.label(GazeFeature(0.50f, 0.60f)))
    }

    @Test fun rejectsTinyRangeOrMissingData() {
        val c = GazeCalibrator()
        fill(c, GazeCalibrator.Target.CENTER, 0.5f, 0.5f)
        assertNull(c.build())
        val flat = GazeCalibrator().also {
            GazeCalibrator.Target.values().forEach { t -> fill(it, t, 0.5f, 0.5f) }
        }
        assertNull(flat.build())
    }

    @Test fun serializationRoundTrip() {
        val cal = good().build()!!
        assertEquals(cal, Calibration.parse(cal.serialize()))
        assertNull(Calibration.parse("garbage"))
    }

    @Test fun gazeMathNeedsFullMesh() {
        assertNull(GazeMath.feature(100, { 0f }, { 0f }))
    }

    @Test fun gazeMathCentered() {
        val xs = FloatArray(478); val ys = FloatArray(478)
        // right eye: corners 33 (outer) .. 133 (inner), iris 468 centered
        xs[33] = 0.30f; xs[133] = 0.40f; xs[468] = 0.35f
        // left eye: corners 362 (inner) .. 263 (outer), iris 473 centered
        xs[362] = 0.60f; xs[263] = 0.70f; xs[473] = 0.65f
        ys[159] = 0.40f; ys[145] = 0.44f; ys[468] = 0.42f
        ys[386] = 0.40f; ys[374] = 0.44f; ys[473] = 0.42f
        val f = GazeMath.feature(478, { xs[it] }, { ys[it] })!!
        assertEquals(0.5f, f.rx, 0.01f)
        assertEquals(0.5f, f.ry, 0.01f)
    }
}
