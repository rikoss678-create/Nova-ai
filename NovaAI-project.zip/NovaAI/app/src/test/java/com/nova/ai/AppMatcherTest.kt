package com.nova.ai

import com.nova.ai.agent.AppMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AppMatcherTest {
    private val apps = listOf(
        "YouTube" to "com.google.android.youtube",
        "WhatsApp" to "com.whatsapp",
        "Chrome" to "com.android.chrome",
        "الإعدادات" to "com.android.settings"
    )

    @Test fun arabicAliasMatchesLatinLabel() {
        assertEquals("com.whatsapp", AppMatcher.best(apps, "واتساب"))
        assertEquals("com.google.android.youtube", AppMatcher.best(apps, "افتح يوتيوب"))
    }

    @Test fun matchesArabicLabel() {
        assertEquals("com.android.settings", AppMatcher.best(apps, "الاعدادات"))
    }

    @Test fun unknownReturnsNull() {
        assertNull(AppMatcher.best(apps, "تطبيق غير موجود"))
    }
}
