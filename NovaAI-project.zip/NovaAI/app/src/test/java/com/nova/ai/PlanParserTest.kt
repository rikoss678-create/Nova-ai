package com.nova.ai

import com.nova.ai.agent.Action
import com.nova.ai.agent.PlanParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanParserTest {
    @Test fun parsesValidPlan() {
        val raw = """```json
            {"reply":"واخا","actions":[{"type":"OPEN_APP","app":"يوتيوب"},{"type":"SCROLL","dir":"up"}],"remember":["يحب كرة القدم"]}
            ```"""
        val p = PlanParser.parse(raw)
        assertEquals("واخا", p.reply)
        assertEquals(listOf(Action.OpenApp("يوتيوب"), Action.Scroll(false)), p.actions)
        assertEquals(listOf("يحب كرة القدم"), p.remember)
    }

    @Test fun dropsUnknownActionsAndBadUrls() {
        val raw = """{"reply":"","actions":[{"type":"FORMAT_DISK"},{"type":"OPEN_URL","url":"javascript:alert(1)"},{"type":"BACK"}]}"""
        val p = PlanParser.parse(raw)
        assertEquals(listOf<Action>(Action.Back), p.actions)
        assertEquals(2, p.ignored)
    }

    @Test fun plainTextBecomesReply() {
        val p = PlanParser.parse("مرحبا")
        assertEquals("مرحبا", p.reply)
        assertTrue(p.actions.isEmpty())
    }

    @Test fun capsNumberOfActions() {
        val one = """{"type":"BACK"}"""
        val raw = """{"reply":"x","actions":[${List(12) { one }.joinToString(",")}]}"""
        val p = PlanParser.parse(raw)
        assertEquals(8, p.actions.size)
        assertEquals(4, p.ignored)
    }
}
