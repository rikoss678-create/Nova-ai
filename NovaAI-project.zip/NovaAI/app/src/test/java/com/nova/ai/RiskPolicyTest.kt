package com.nova.ai

import com.nova.ai.agent.Action
import com.nova.ai.agent.RiskPolicy
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class RiskPolicyTest {
    @Test fun smsAndCallNeedConfirmation() {
        assertNotNull(RiskPolicy.reason(Action.ComposeSms("0555", "hi")))
        assertNotNull(RiskPolicy.reason(Action.Call("0555")))
    }

    @Test fun sensitiveClicksNeedConfirmation() {
        assertNotNull(RiskPolicy.reason(Action.ClickText("إرسال")))
        assertNotNull(RiskPolicy.reason(Action.ClickText("Delete all")))
        assertNotNull(RiskPolicy.reason(Action.ClickText("ادفع الآن")))
    }

    @Test fun harmlessActionsDoNot() {
        assertNull(RiskPolicy.reason(Action.ClickText("بحث")))
        assertNull(RiskPolicy.reason(Action.OpenApp("واتساب")))
        assertNull(RiskPolicy.reason(Action.Scroll(true)))
    }
}
